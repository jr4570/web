/*******************************************
 *  �{���W�� : 9-3.cpp ( �ʤ�ʸ} 5 )
 *  �{������ : ���O���󪺽m��
 *******************************************/


#include <iostream>
#include <cstdio>
#include <ctime>
#include <windows.h>
#include <conio.h>
using namespace std;
const int N=15;

class Point {
public:
	int x,y;
void set(int X, int Y)
{x=X;y=Y;}
};

HANDLE	hIn,hOut;			//�ù����
Point		body,obstacle[6];		//����A��ê��
char			room[N][N*2+4];		//�~�ؤj�p 
int			delay_time=42,tt=5,up_down=0,mou=0;
//tt ��delay�X������𩹫e����,up_down�����W�Ω��U���Ѽ�,mou���L����
bool			bExit=false;			//�C���O�_���� 

void gotoxy(int x,int y)
{
static COORD c;
c.X=x;
c.Y=y;
SetConsoleCursorPosition(hOut,c);
}

void draw(int x, int y, char* s1,int mou=-1)
{
gotoxy(x,y);
if (mou==-1)
		cout<<s1;
else
		cout<<s1<<mou;
}

void drawList(char* a, char* b, char* c, int w, int h=1)
{
static char* p=room[0];
for (int i;h--;*p++=*c,*p++=c[1],*p++=0,p++)
	for (*p++='\n',*p++=*a,*p++=a[1],*p++=a[2],i=w-2;i--;)
			{*p++=*b;*p++=b[1];} 
}

void put_obstacle()
{	
	if (obstacle[0].x<4) {
		for (int i =0;i<7;i++) {
			draw(obstacle[i].x,obstacle[i].y,"�@");
			obstacle[i].y=(rand()%8)+2;
			obstacle[i].x=24; }
		draw(7,11,"�L����: ",mou++);
	}
}

void init()	//��� 
{
srand(unsigned(time(NULL)));
hOut=GetStdHandle(STD_OUTPUT_HANDLE);
hIn=GetStdHandle(STD_INPUT_HANDLE);

drawList(" �z","�w","�{",N);
drawList(" �x","  ","�x",N,8);
drawList(" �|","�w","�}",N);
gotoxy(0,0);
for (int i=0; i<N; i++)
		cout<<room[i];
body.set(4,4);
}

void key_control()
{
static DWORD count;
static INPUT_RECORD ir;
ReadConsoleInput(hIn,&ir,1,&count);
if (!ir.Event.KeyEvent.bKeyDown) return;
switch (ir.Event.KeyEvent.wVirtualKeyCode) {
	case VK_UP:
		up_down=-1; break;
		case VK_DOWN:
			up_down=1; break;
	}
}

void move()
{
	int& x=body.x;
int& y=body.y;
body.y+=up_down;

draw(4,body.y+(-1*up_down),"�@");
up_down=0;
	draw(body.x, body.y,"�h");
tt--;
put_obstacle();
	if (tt==0) {
		if (delay_time>5) delay_time-=1;
		tt=5;
		for (int i =0;i<7;i++)
			obstacle[i].x--;
	}
if (y==10||y==1) { //����
	draw(7,13,"Game  Over !!!");
	draw(7,11,"�L����: ",mou++);
		bExit=true;
}
for(int i =0;i<7;i++) {
	if ((x == obstacle[i].x && y == obstacle[i].y)) { //�I���ê��
			draw(7,13,"Game  Over !!!");
			draw(7,11,"�L����: ",mou++);
			bExit=true; }
	}
}

main()
{
	init();
	draw(0,0,"�ϥΤW�U�䱱��G");
	system("Pause");
	while (!bExit) {
		put_obstacle();
		Sleep(delay_time);
		if (kbhit()) key_control();
		for (int i =0;i<7;i++)
			draw(obstacle[i].x, obstacle[i].y,"��");
		move();
	}
}

