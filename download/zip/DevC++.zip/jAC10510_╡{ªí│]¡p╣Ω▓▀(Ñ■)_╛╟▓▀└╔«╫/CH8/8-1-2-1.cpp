/*******************************************
 *  �{���W�� : 8-1-2-1.cpp ( �ʤ�ʸ} 2 )
 *  �{������ : �üƨ禡���򥻽m��
 *******************************************/
 
#include <iostream>
#include <iomanip>
#include <cstdlib>
#include <ctime>
using std::cin;
using std::cout;
using std::endl;

main()
{
	int i,num;
	srand((unsigned int)time(NULL));
	
	for(i=0;i<10;i++){
		num=rand()%100+1;
			cout<<"�üƭ�:"<<num<<endl;
	}
	system("Pause");
}

