/*******************************************
 *  �{���W�� : 8-1-3.cpp ( �ʤ�ʸ} 4 )
 *  �{������ : ��ƨD�Ѩ禡���򥻽m��
 *******************************************/

#include <iostream>
#include <iomanip>
#include <cmath>
using std::cin;
using std::cout;
using std::endl;

main()
{
	double v1,v2,v3,v4,v5;

	v1=ceil(3.1);
	v2=floor(4.9);
	v3=round(5.4);
	v4=round(5.5);
	v5=abs(-10);

	cout<<"v1="<<v1<<endl;
	cout<<"v2="<<v2<<endl;
	cout<<"v3="<<v3<<endl;
	cout<<"v4="<<v4<<endl;
	cout<<"v5="<<v5<<endl;
	system("Pause");
}

