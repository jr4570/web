/*******************************************
 *  �{���W�� : 8-3-1.cpp ( �ʤ�ʸ} 14 )
 *  �{������ : ���J�P�۰ʵo�P��
 *******************************************/
 
#include <iostream>
#include <iomanip>
#include <ctime>
#include <cstdlib>
#include <windows.h>
using std::cout;
using std::endl;
using std::setw;

void sort(int *array);

main()
{
	int i,j,temp,suit,num;
	int card[52],player[4][13];
	char pattern[4]={char(5),char(4),char(3),char(6)};
	srand((unsigned int)time(NULL));
	//��l��
	for(i=0;i<52;i++)
		card[i]=i;
	//�~�P
	for(i=0;i<52;i++){
		j=rand()%52;
		temp=card[i];
		card[i]=card[j];
		card[j]=temp;
	}
	//�o�P  
	for(i=0;i<4;i++)
		for(j=0;j<13;j++)
			player[i][j]=card[i*13+j];
			
	//��z�P��
	for(i=0;i<4;i++)
		sort(player[i]);
	//��� 
	cout<<"A deck of playing cards as follows:"<<endl; 
	for(i=0;i<4;i++){
		cout<<"Player #"<<i+1<<":";
		for(j=0;j<13;j++){
			suit=player[i][j]/13;
			num=player[i][j]%13+1;
			cout<<setw(3)<<pattern[suit]<<setw(2);
			switch(num){
				case  1:cout<<"A";break;
				case 11:cout<<"J";break;
				case 12:cout<<"Q";break;
				case 13:cout<<"K";break;
				default:cout<<num;
			}
		}
		cout<<endl;
	}
	system("Pause");
}


void sort(int *array)
{
	int i, j, temp, weight1, weight2;
	for(i=0;i<13;i++)
		for(j=0;j<12;j++){
			weight1 = array[j] % 13 * 10 + array[j] / 13;
			weight2 = array[j+1] % 13 * 10 + array[j+1] / 13;
			if(weight1 > weight2){
				temp=array[j];
				array[j]=array[j+1];
				array[j+1]=temp;
			}
		}
}

